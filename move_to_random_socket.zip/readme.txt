실행할때 objects 태그가 있는 object를 sockets 태그가 있는 object(socket)에 랜덤하게 배치
스크립트 "MoveToSocket"에 작성해서 Scene "New"의 Object "MoveToSocket"에 할당함
* 위치가 중복되는 문제 (스크린샷(2)) 해결 필요
* 5개중 2개는 맞는 위치, 3개만 틀린 위치로 이동하는 기능 구현 필요